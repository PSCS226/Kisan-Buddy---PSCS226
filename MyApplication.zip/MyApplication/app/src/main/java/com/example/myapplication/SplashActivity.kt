package com.example.myapplication

import android.content.Intent
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import android.os.Bundle

import androidx.appcompat.app.AppCompatActivity
import com.example.myapplication.MainActivity

class SplashActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        // Delay for 2-3 seconds (2000 milliseconds)
        Executors.newSingleThreadScheduledExecutor().schedule({
            // Code to execute after the delay
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish()
        }, 2, TimeUnit.SECONDS) // Delay of 2 seconds
    }
}
