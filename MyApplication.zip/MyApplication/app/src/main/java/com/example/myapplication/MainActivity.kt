package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import com.google.android.material.bottomnavigation.BottomNavigationView

class MainActivity : AppCompatActivity() {

    private lateinit var searchView: SearchView
    private lateinit var cropGrid: GridLayout
    private lateinit var scrollView: ScrollView

    private val crops = listOf(
        "Wheat(KG)", "Rice(KG)", "Maize(Pcs)", "Barley(KG)", "Oats(KG)",
        "Soybean(KG)", "Sugarcane(Pcs)", "Cotton(KG)", "Potato(KG)", "Tomato(KG)",
        "Onion(KG)", "Garlic(KG)", "Pepper(KG)", "Cucumber(KG)", "Carrot(KG)",
        "Spinach(Pcs)", "Peas(KG)", "Lettuce(Pcs)", "Strawberry(KG)", "Mango(KG)"
    )

    private val cropImages = listOf(
        R.drawable.wheat, R.drawable.rice, R.drawable.maize, R.drawable.barley, R.drawable.oats,
        R.drawable.soybean, R.drawable.sugarcane, R.drawable.cotton, R.drawable.potato, R.drawable.tomato,
        R.drawable.onion, R.drawable.garlic, R.drawable.pepper, R.drawable.cucumber, R.drawable.carrot,
        R.drawable.spinach, R.drawable.peas, R.drawable.lettuce, R.drawable.strawberry, R.drawable.mango
    )

    private val cropCounts = MutableList(crops.size) { 0 } // Initialize counts with 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        searchView = findViewById(R.id.searchView)
        cropGrid = findViewById(R.id.cropGrid)
        scrollView = findViewById(R.id.scrollView)

        // Populate GridLayout with crops
        populateGrid()

        // Set up SearchView filtering
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                return false
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                filterGrid(newText)
                return true
            }
        })

        // Bottom Navigation Setup
        val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNav)
        bottomNav.setOnNavigationItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.nav_home -> {
                    // Show crops grid
                    scrollView.visibility = ScrollView.VISIBLE
                    true
                }
                R.id.nav_profile -> {
                    // Open Profile Activity
                    startActivity(Intent(this, ProfileActivity::class.java))
                    scrollView.visibility = ScrollView.GONE
                    true
                }
                R.id.nav_cart -> {
                    // Open Cart Activity
                    val cartItems = crops.indices
                        .filter { cropCounts[it] > 1 }
                        .map { cropImages[it] to crops[it] }
                    val intent = Intent(this, CartActivity::class.java)
                    intent.putExtra("cartItems", ArrayList(cartItems))
                    startActivity(intent)
                    scrollView.visibility = ScrollView.GONE
                    true
                }
                else -> false
            }
        }

        // Default selection: Home
        bottomNav.selectedItemId = R.id.nav_home
    }

    private fun populateGrid() {
        cropGrid.removeAllViews()
        for (i in crops.indices) {
            val itemContainer = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = GridLayout.LayoutParams().apply {
                    width = 0
                    height = GridLayout.LayoutParams.WRAP_CONTENT
                    columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                    setMargins(8, 8, 8, 8)
                }
            }

            // ImageView
            val imageView = ImageView(this).apply {
                setImageResource(cropImages[i])
                layoutParams = LinearLayout.LayoutParams(350, 350).apply {
                    gravity = Gravity.CENTER
                }
                scaleType = ImageView.ScaleType.CENTER_CROP
            }

            // TextView
            val textView = TextView(this).apply {
                text = crops[i]
                textAlignment = TextView.TEXT_ALIGNMENT_CENTER
                textSize = 20f
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    setMargins(0, 8, 0, 0)
                    gravity = Gravity.CENTER
                }
            }

            // Counter Buttons Layout
            val counterLayout = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
            }

            val decrementButton = Button(this).apply {
                text = "−"
                textSize = 30f
                gravity = Gravity.CENTER
                setBackgroundColor(resources.getColor(R.color.light_blue))
                setTextColor(resources.getColor(R.color.black))
                layoutParams = LinearLayout.LayoutParams(120, 120)
                setPadding(10, 10, 10, 10)
                setOnClickListener {
                    if (cropCounts[i] > 0) cropCounts[i]--
                    updateCounterText(i, itemContainer)
                }
            }

            val counterText = TextView(this).apply {
                text = cropCounts[i].toString()
                textAlignment = TextView.TEXT_ALIGNMENT_CENTER
                textSize = 26f
                gravity = Gravity.CENTER
            }

            val incrementButton = Button(this).apply {
                text = "+"
                textSize = 30f
                gravity = Gravity.CENTER
                setBackgroundColor(resources.getColor(R.color.light_blue))
                setTextColor(resources.getColor(R.color.black))
                layoutParams = LinearLayout.LayoutParams(120, 120)
                setPadding(10, 10, 10, 10)
                setOnClickListener {
                    cropCounts[i]++
                    updateCounterText(i, itemContainer)
                }
            }

            counterLayout.addView(decrementButton)
            counterLayout.addView(counterText)
            counterLayout.addView(incrementButton)

            itemContainer.addView(imageView)
            itemContainer.addView(textView)
            itemContainer.addView(counterLayout)
            cropGrid.addView(itemContainer)
        }
    }

    private fun updateCounterText(index: Int, container: LinearLayout) {
        val counterLayout = container.getChildAt(2) as LinearLayout
        val textView = counterLayout.getChildAt(1) as TextView
        textView.text = cropCounts[index].toString()
    }

    private fun filterGrid(query: String?) {
        cropGrid.removeAllViews()
        if (query.isNullOrEmpty()) {
            populateGrid()
            return
        }
        for (i in crops.indices) {
            if (crops[i].contains(query, ignoreCase = true)) {
                val itemContainer = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    layoutParams = GridLayout.LayoutParams().apply {
                        width = 0
                        height = GridLayout.LayoutParams.WRAP_CONTENT
                        columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                        setMargins(8, 8, 8, 8)
                    }
                }

                val imageView = ImageView(this).apply {
                    setImageResource(cropImages[i])
                    layoutParams = LinearLayout.LayoutParams(300, 300).apply {
                        gravity = Gravity.CENTER
                    }
                    scaleType = ImageView.ScaleType.CENTER_CROP
                }

                val textView = TextView(this).apply {
                    text = crops[i]
                    textAlignment = TextView.TEXT_ALIGNMENT_CENTER
                    textSize = 26f
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    ).apply {
                        setMargins(0, 8, 0, 0)
                        gravity = Gravity.CENTER
                    }
                }

                itemContainer.addView(imageView)
                itemContainer.addView(textView)
                cropGrid.addView(itemContainer)
            }
        }
    }
}
