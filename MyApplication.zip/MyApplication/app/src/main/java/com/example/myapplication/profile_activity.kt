package com.example.myapplication

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class ProfileActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        findViewById<Button>(R.id.signInButton).setOnClickListener {
            val userId = findViewById<EditText>(R.id.userIdInput).text.toString()
            val password = findViewById<EditText>(R.id.passwordInput).text.toString()

            if (userId.isNotEmpty() && password.isNotEmpty()) {
                Toast.makeText(this, "Logged in as $userId", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
            }
        }

        findViewById<TextView>(R.id.registerLink).setOnClickListener {
            Toast.makeText(this, "Registration page coming soon", Toast.LENGTH_SHORT).show()
        }
    }
}
