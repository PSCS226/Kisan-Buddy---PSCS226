package com.example.myapplication

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class CartActivity : AppCompatActivity() {

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cart)

        val cartItems = intent.getSerializableExtra("cartItems") as? List<Pair<Int, String>> ?: return

        val container = findViewById<LinearLayout>(R.id.cartContainer)

        cartItems.forEach { (imageRes, cropName) ->
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
                setPadding(8, 8, 8, 8)
            }

            val imageView = ImageView(this).apply {
                setImageResource(imageRes)
                layoutParams = LinearLayout.LayoutParams(100, 100)
            }

            val textView = TextView(this).apply {
                text = cropName
                textSize = 16f
                setPadding(16, 0, 0, 0)
            }

            item.addView(imageView)
            item.addView(textView)
            container.addView(item)
        }
    }
}
